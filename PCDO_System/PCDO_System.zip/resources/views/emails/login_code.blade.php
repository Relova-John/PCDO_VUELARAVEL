<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Login Code</title>
</head>
<body>
    <p>Your login code is: <strong>{{ $code }}</strong></p>
    <p>This code will expire in 5 minutes.</p>
</body>
</html>