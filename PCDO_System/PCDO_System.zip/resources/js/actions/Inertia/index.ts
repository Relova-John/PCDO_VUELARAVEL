import Controller from './Controller'
const Inertia = {
    Controller: Object.assign(Controller, Controller),
}

export default Inertia