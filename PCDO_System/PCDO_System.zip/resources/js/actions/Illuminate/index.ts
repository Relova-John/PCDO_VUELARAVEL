import Routing from './Routing'
const Illuminate = {
    Routing: Object.assign(Routing, Routing),
}

export default Illuminate