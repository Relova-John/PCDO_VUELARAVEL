import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
export const sync = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sync.url(options),
    method: 'get',
})

sync.definition = {
    methods: ["get","head"],
    url: '/sync',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
sync.url = (options?: RouteQueryOptions) => {
    return sync.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
sync.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sync.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
sync.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sync.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
    const syncForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sync.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
        syncForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sync.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SyncController::sync
 * @see app/Http/Controllers/SyncController.php:0
 * @route '/sync'
 */
        syncForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sync.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sync.form = syncForm
const SyncController = { sync }

export default SyncController