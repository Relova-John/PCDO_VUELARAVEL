import Auth from './Auth'
import CooperativesController from './CooperativesController'
import SyncController from './SyncController'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
CooperativesController: Object.assign(CooperativesController, CooperativesController),
SyncController: Object.assign(SyncController, SyncController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers