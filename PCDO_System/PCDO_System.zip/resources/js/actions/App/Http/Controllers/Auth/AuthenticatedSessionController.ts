import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:22
 * @route '/login'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:33
 * @route '/login'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:33
 * @route '/login'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:33
 * @route '/login'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:33
 * @route '/login'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:33
 * @route '/login'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:89
 * @route '/logout'
 */
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:89
 * @route '/logout'
 */
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:89
 * @route '/logout'
 */
destroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:89
 * @route '/logout'
 */
    const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:89
 * @route '/logout'
 */
        destroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(options),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
export const verifyCodeForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyCodeForm.url(options),
    method: 'get',
})

verifyCodeForm.definition = {
    methods: ["get","head"],
    url: '/login/verify',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
verifyCodeForm.url = (options?: RouteQueryOptions) => {
    return verifyCodeForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
verifyCodeForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyCodeForm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
verifyCodeForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyCodeForm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
    const verifyCodeFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verifyCodeForm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
        verifyCodeFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyCodeForm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:57
 * @route '/login/verify'
 */
        verifyCodeFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyCodeForm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verifyCodeForm.form = verifyCodeFormForm
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyPostCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
export const verifyPostCodeForm = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyPostCodeForm.url(options),
    method: 'post',
})

verifyPostCodeForm.definition = {
    methods: ["post"],
    url: '/login/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyPostCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
verifyPostCodeForm.url = (options?: RouteQueryOptions) => {
    return verifyPostCodeForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyPostCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
verifyPostCodeForm.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyPostCodeForm.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyPostCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
    const verifyPostCodeFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyPostCodeForm.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::verifyPostCodeForm
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
        verifyPostCodeFormForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyPostCodeForm.url(options),
            method: 'post',
        })
    
    verifyPostCodeForm.form = verifyPostCodeFormForm
const AuthenticatedSessionController = { create, store, destroy, verifyCodeForm, verifyPostCodeForm }

export default AuthenticatedSessionController