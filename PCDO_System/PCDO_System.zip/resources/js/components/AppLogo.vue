<script setup lang="ts">
</script>

<template>
    <div class="w-12 h-12 flex items-center justify-center rounded-full bg-white overflow-hidden">
        <img src="/img/pcdo_logo.png" alt="App Logo" class="w-full h-full object-contain" />
    </div>
    <div class="ml-1 grid flex-1 text-left text-sm">
        <span class="mb-0.5 truncate leading-tight font-semibold">PCDO</span>
    </div>
</template>
