import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::post
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
export const post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: post.url(options),
    method: 'post',
})

post.definition = {
    methods: ["post"],
    url: '/login/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::post
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
post.url = (options?: RouteQueryOptions) => {
    return post.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::post
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
post.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: post.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::post
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
    const postForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: post.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\AuthenticatedSessionController::post
 * @see app/Http/Controllers/Auth/AuthenticatedSessionController.php:65
 * @route '/login/verify'
 */
        postForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: post.url(options),
            method: 'post',
        })
    
    post.form = postForm
const verify = {
    post: Object.assign(post, post),
}

export default verify