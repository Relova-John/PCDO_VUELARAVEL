import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/cooperatives',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CooperativesController::index
 * @see app/Http/Controllers/CooperativesController.php:17
 * @route '/cooperatives'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/cooperatives/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CooperativesController::create
 * @see app/Http/Controllers/CooperativesController.php:48
 * @route '/cooperatives/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\CooperativesController::store
 * @see app/Http/Controllers/CooperativesController.php:71
 * @route '/cooperatives'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/cooperatives',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CooperativesController::store
 * @see app/Http/Controllers/CooperativesController.php:71
 * @route '/cooperatives'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::store
 * @see app/Http/Controllers/CooperativesController.php:71
 * @route '/cooperatives'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CooperativesController::store
 * @see app/Http/Controllers/CooperativesController.php:71
 * @route '/cooperatives'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::store
 * @see app/Http/Controllers/CooperativesController.php:71
 * @route '/cooperatives'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
export const show = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/cooperatives/{cooperative}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
show.url = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cooperative: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cooperative: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cooperative: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cooperative: typeof args.cooperative === 'object'
                ? args.cooperative.id
                : args.cooperative,
                }

    return show.definition.url
            .replace('{cooperative}', parsedArgs.cooperative.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
show.get = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
show.head = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
    const showForm = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
        showForm.get = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CooperativesController::show
 * @see app/Http/Controllers/CooperativesController.php:129
 * @route '/cooperatives/{cooperative}'
 */
        showForm.head = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
export const edit = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/cooperatives/{cooperative}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
edit.url = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cooperative: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cooperative: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cooperative: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cooperative: typeof args.cooperative === 'object'
                ? args.cooperative.id
                : args.cooperative,
                }

    return edit.definition.url
            .replace('{cooperative}', parsedArgs.cooperative.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
edit.get = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
edit.head = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
    const editForm = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
        editForm.get = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CooperativesController::edit
 * @see app/Http/Controllers/CooperativesController.php:145
 * @route '/cooperatives/{cooperative}/edit'
 */
        editForm.head = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
export const update = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/cooperatives/{cooperative}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
update.url = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cooperative: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cooperative: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cooperative: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cooperative: typeof args.cooperative === 'object'
                ? args.cooperative.id
                : args.cooperative,
                }

    return update.definition.url
            .replace('{cooperative}', parsedArgs.cooperative.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
update.put = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
update.patch = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
    const updateForm = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
        updateForm.put = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CooperativesController::update
 * @see app/Http/Controllers/CooperativesController.php:161
 * @route '/cooperatives/{cooperative}'
 */
        updateForm.patch = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CooperativesController::destroy
 * @see app/Http/Controllers/CooperativesController.php:179
 * @route '/cooperatives/{cooperative}'
 */
export const destroy = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/cooperatives/{cooperative}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CooperativesController::destroy
 * @see app/Http/Controllers/CooperativesController.php:179
 * @route '/cooperatives/{cooperative}'
 */
destroy.url = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cooperative: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cooperative: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cooperative: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cooperative: typeof args.cooperative === 'object'
                ? args.cooperative.id
                : args.cooperative,
                }

    return destroy.definition.url
            .replace('{cooperative}', parsedArgs.cooperative.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::destroy
 * @see app/Http/Controllers/CooperativesController.php:179
 * @route '/cooperatives/{cooperative}'
 */
destroy.delete = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CooperativesController::destroy
 * @see app/Http/Controllers/CooperativesController.php:179
 * @route '/cooperatives/{cooperative}'
 */
    const destroyForm = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::destroy
 * @see app/Http/Controllers/CooperativesController.php:179
 * @route '/cooperatives/{cooperative}'
 */
        destroyForm.delete = (args: { cooperative: string | { id: string } } | [cooperative: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/cooperatives/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CooperativesController::exportMethod
 * @see app/Http/Controllers/CooperativesController.php:207
 * @route '/cooperatives/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\CooperativesController::importMethod
 * @see app/Http/Controllers/CooperativesController.php:188
 * @route '/cooperatives/import'
 */
export const importMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importMethod.url(options),
    method: 'post',
})

importMethod.definition = {
    methods: ["post"],
    url: '/cooperatives/import',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CooperativesController::importMethod
 * @see app/Http/Controllers/CooperativesController.php:188
 * @route '/cooperatives/import'
 */
importMethod.url = (options?: RouteQueryOptions) => {
    return importMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CooperativesController::importMethod
 * @see app/Http/Controllers/CooperativesController.php:188
 * @route '/cooperatives/import'
 */
importMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CooperativesController::importMethod
 * @see app/Http/Controllers/CooperativesController.php:188
 * @route '/cooperatives/import'
 */
    const importMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: importMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CooperativesController::importMethod
 * @see app/Http/Controllers/CooperativesController.php:188
 * @route '/cooperatives/import'
 */
        importMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: importMethod.url(options),
            method: 'post',
        })
    
    importMethod.form = importMethodForm
const cooperatives = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
export: Object.assign(exportMethod, exportMethod),
import: Object.assign(importMethod, importMethod),
}

export default cooperatives