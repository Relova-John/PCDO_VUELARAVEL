<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Login Code</title>
</head>
<body>
    <p>Your login code is: <strong><?php echo e($code); ?></strong></p>
    <p>This code will expire in 5 minutes.</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\Relova\PCDO_VUELARAVEL\PCDO_System\resources\views/emails/login_code.blade.php ENDPATH**/ ?>