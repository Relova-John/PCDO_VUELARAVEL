<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Relova\PCDO_VUELARAVEL\PCDO_System\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>